package com.example.booksapp;

public class ItemData {
    public String itemTitle;
    public String itemAuthor;
    public String itemImage;
    public String itemDescription;
}
